---
name: meli-description
description: Crie ou revise descrições comerciais factuais de produtos e kits para Mercado Livre Brasil.
---

# Descrição MeLi

Escreva em português do Brasil, com 1.200–1.500 caracteres úteis. Use parágrafos curtos e listas quando ajudarem na leitura.

Comece pela finalidade do produto e pelo benefício prático. Apresente o conteúdo da compra e inclua funções, materiais, medidas, aplicações, compatibilidade, cuidados, limitações e itens não inclusos quando relevantes e confirmados.

Use as informações do usuário e as referências do produto exato. Produtos similares só servem como referência de linguagem. Omita atributos, garantias, certificações e avaliações sem comprovação.

Entregue somente a descrição. Se solicitado salvar no projeto, grave em `Descrição.txt` na pasta do anúncio, sem título, rótulos de entrega ou metadados.
