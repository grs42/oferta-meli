---
name: meli-title-optimizer
description: Pesquise linguagem e intenção no Mercado Livre Brasil e entregue um único título factual, sem marca, entre 58 e 60 caracteres. Use para criar, revisar ou validar títulos MeLi; não use para imagens ou descrições.
---

# Otimizador de Títulos MeLi

## Responsabilidade exclusiva

Esta skill é a única autoridade de pesquisa de palavras-chave e construção do
título. Recebe Product Truth e palavras-chave do usuário, pesquisa o Mercado
Livre e devolve um único título liberável. Não cria galeria, descrição, ficha
técnica ou estratégia visual.

Leia `CREATIVE_DIRECTOR.md` e preserve sua hierarquia factual. Pesquisa mede
linguagem e intenção; nunca cria atributo do produto.

## Contrato de saída

- Mercado Livre Brasil e português do Brasil.
- **58–60 caracteres**, incluindo espaços.
- Sem marca, fabricante ou concorrente.
- Sem filler, repetição, keyword stuffing ou claim não comprovado.
- Produto/tipo principal aparece com clareza.
- Cada termo adicional acrescenta intenção de busca ou diferenciação factual.
- Título com 57 caracteres ou menos é `blocked`, mesmo quando gramaticalmente
  correto.
- Marca visível no produto pode permanecer nas imagens, mas não entra no título.

## Entradas

Receba somente fatos consolidados:

```text
product_type, category, attributes, specifications, features, use_cases,
included_items, dimensions, material, color, quantity, compatibility,
additional_verified_facts, known_keywords,
user_authorized_commercial_keywords, brands_to_exclude
```

Termo factual explicitamente fornecido pelo usuário integra o Product Truth.
Descritor promocional autorizado pelo usuário pode competir pelo título, mas
não confirma material, medida, segurança, capacidade ou desempenho.

## Pesquisa autônoma obrigatória

Quando houver browser ou busca disponível, tome a iniciativa sem pedir que o
usuário repita o caminho:

1. consulte **Mercado Livre Tendências** para os seeds do produto;
2. consulte busca interna/autocomplete/resultados públicos do Mercado Livre;
3. observe títulos relevantes, atributos de categoria, variações linguísticas
   e sinais públicos disponíveis, sem inventar volume ou ranking;
4. registre `research_provenance` com superfície, consulta, URL, data e termos
   efetivamente observados;
5. use a pesquisa para alterar clusters, prioridades e candidatos.

Fallback: se Tendências estiver indisponível, use busca interna e resultados
públicos do Mercado Livre. Se nenhuma superfície MeLi puder ser consultada,
retorne `blocked: research_unavailable`. Não declare pesquisa concluída e não
use outro marketplace como substituto.

## Construção

1. Monte uma whitelist de frases factuais do Product Truth.
2. Normalize e deduplique as observações de mercado.
3. Separe clusters: identidade, medida, quantidade, material, função,
   configuração, aplicação e público.
4. Rejeite `BRAND`, `UNSUPPORTED`, `IRRELEVANT`, `DUPLICATE` e `FILLER`.
5. Gere 8–15 candidatos naturais, testando ordem, swaps e formas compactas
   factualmente equivalentes.
6. Compare cobertura marginal de consultas por caractere.
7. Se o melhor candidato tiver menos de 58, continue pesquisando e combinando;
   não o libere.
8. Valide deterministicamente e congele o melhor título entre 58–60.

Não empilhe sinônimos do mesmo cluster. Formas como `8"`, `5m`, `6 Pçs` ou
`C Trava` só são usadas quando naturais para a categoria, factualmente
equivalentes e úteis para abrir espaço a outro termo relevante.

## Evidência e limites

- Sugestões e linguagem observadas ajudam a estimar intenção, não provam fatos.
- Título concorrente nunca transfere material, medida ou compatibilidade.
- Página pública só confirma um fato quando identifica o produto exato e a URL
  fica registrada.
- Não invente volume, CTR, CPC, ranking, tendência, visitas ou vendas.
- Não use `produto`, `qualidade`, `ideal`, `excelente`, `super` ou
  `premium` para completar caracteres.

## Scripts

- `scripts/keyword_research.py`: estrutura evidência e provenance fornecidas
  pela pesquisa realmente executada; não navega sozinho.
- `scripts/keyword_processor.py`: filtra Product Truth, marcas e termos sem
  suporte.
- `scripts/title_generator.py`: gera e compara candidatos.
- `scripts/title_validator.py`: aplica o intervalo 58–60 e os hard gates.

## Saída

```json
{
  "title": "...",
  "character_count": 59,
  "character_minimum": 58,
  "character_limit": 60,
  "research_provenance": [
    {"surface": "meli_search", "query": "...", "url": "...", "observed_terms": ["..."]}
  ],
  "candidates_compared": 10,
  "validation": {
    "valid": true,
    "brand_free": true,
    "within_range": true,
    "research_verified": true
  }
}
```

Se não houver título factual de 58–60 ou pesquisa MeLi verificável, retorne
`validation.valid: false` e um motivo de bloqueio. A `oferta-meli` não pode
reescrever, encurtar ou completar o resultado localmente.
