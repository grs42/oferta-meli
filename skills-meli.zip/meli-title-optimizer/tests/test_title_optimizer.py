from __future__ import annotations

import sys
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from keyword_processor import build_keyword_pool, build_query_universe
from keyword_research import build_search_intelligence, collect_evidence
from title_generator import generate_candidates, optimize, optimize_for_release, score_candidate
from title_validator import CHARACTER_LIMIT, MIN_CHARACTER_TARGET, validate_release_title, validate_title


def product(**overrides):
    data = {
        "product_type": ["furadeira parafusadeira", "parafusadeira"],
        "attributes": ["20V", "impacto", "2 baterias", "maleta"],
        "brand": "MarcaTeste",
    }
    data.update(overrides)
    return data


def processed(product_data=None, terms=None, brands=()):
    evidence = [{"term": term, "source_level": 3, "source": "test"} for term in (terms or product()["product_type"] + product()["attributes"])]
    result = build_keyword_pool(product_data or product(), evidence, brands)
    result["query_universe"] = build_query_universe(result["keyword_pool"])
    return result


class TitleOptimizerTests(unittest.TestCase):
    def test_release_floor_is_58_characters(self):
        self.assertEqual(MIN_CHARACTER_TARGET, 58)
        self.assertFalse(validate_release_title("x" * 57)["valid"])
        self.assertTrue(validate_release_title("x" * 58)["valid"])

    def test_release_requires_observed_meli_research_when_requested(self):
        blocked = validate_release_title("x" * 58, require_research=True, research_provenance=[])
        self.assertFalse(blocked["valid"])
        self.assertIn("missing_meli_research_provenance", blocked["violations"])
        valid = validate_release_title(
            "x" * 58,
            require_research=True,
            research_provenance=[{
                "surface": "meli_search",
                "query": "alicate universal",
                "url": "https://lista.mercadolivre.com.br/alicate-universal",
                "observed_terms": ["alicate universal"],
            }],
        )
        self.assertTrue(valid["valid"])

    def test_production_optimizer_fails_closed_without_research(self):
        data = processed(
            {"product_type": ["alicate universal"], "attributes": ["8 polegadas", "aço Cr-V", "eletricista"]},
            ["alicate universal", "8 polegadas", "aço Cr-V", "eletricista", "profissional"],
        )
        result = optimize_for_release(data)
        self.assertFalse(result["validation"]["valid"])
        self.assertIn("missing_meli_research_provenance", result["validation"]["violations"])

    def test_production_optimizer_accepts_complete_meli_provenance(self):
        intelligence = build_search_intelligence({
            "product": {"product_type": ["alicate universal"], "attributes": ["8 polegadas", "aço Cr-V", "eletricista"]},
            "known_keywords": ["alicate universal", "8 polegadas", "aço Cr-V", "eletricista", "profissional"],
            "meli_observations": {
                "surface": "meli_search",
                "query": "alicate universal 8",
                "source_url": "https://lista.mercadolivre.com.br/alicate-universal-8",
                "results": ["Alicate Universal 8 Aço Cr-V Profissional Eletricista"],
            },
        })
        result = optimize_for_release(intelligence)
        self.assertTrue(result["validation"]["research_verified"])

    def test_exactly_60_characters(self):
        title = "x" * 60
        self.assertEqual(len(title), 60)
        self.assertTrue(validate_title(title)["within_limit"])

    def test_59_characters(self):
        title = "x" * 59
        self.assertEqual(len(title), 59)
        self.assertTrue(validate_title(title)["within_limit"])

    def test_short_title_is_blocked_even_when_no_relevant_term_still_fits(self):
        title = "Alicate Universal 8\" Aço Cr-V Profissional Eletricista"
        self.assertFalse(validate_release_title(title)["valid"])
        self.assertIn("below_58_characters", validate_release_title(title)["violations"])
        verdict = validate_release_title(title, eligible_incremental_terms_that_fit=["1000V"])
        self.assertFalse(verdict["valid"])
        self.assertIn("unused_eligible_incremental_term", verdict["violations"])

    def test_release_validation_cannot_ignore_an_eligible_keyword_that_fits(self):
        title = "Jogo Chave Catraca 19 Peças Soquetes Bits Aço Cr-V"
        release = validate_release_title(title, eligible_incremental_terms_that_fit=["Kit"])
        self.assertFalse(release["valid"])
        self.assertIn("unused_eligible_incremental_term", release["violations"])

    def test_optimizer_blocks_when_facts_cannot_reach_release_floor(self):
        result = optimize(processed({"product_type": "alicate", "brand": "MarcaTeste"}, ["alicate"]))
        self.assertFalse(result["validation"]["valid"])
        self.assertIn("below_58_characters", result["validation"]["violations"])
        self.assertEqual(result["remaining_character_analysis"]["status"], "no_eligible_incremental_coverage_fits")

    def test_optimizer_releases_an_exact_60_character_title_when_facts_support_it(self):
        product_data = {
            "product_type": ["alicate universal"],
            "attributes": ["bico meia cana", "corte"],
            "quantity": "3 unidades",
        }
        intelligence = build_search_intelligence({
            "product": product_data,
            "known_keywords": ["alicate universal", "bico meia cana", "corte", "3 un"],
            "user_authorized_commercial_keywords": ["profissional", "kit"],
        })
        result = optimize(intelligence)
        self.assertTrue(result["validation"]["valid"])
        self.assertEqual(result["character_count"], 60)
        self.assertIn("profissional", result["title"].lower())
        self.assertIn("3 un", result["title"].lower())

    def test_explicit_compact_unit_can_be_used_as_the_same_fact(self):
        data = processed(
            {"product_type": ["alicate universal"], "dimensions": ['8"'], "quantity": ["1 unidade"]},
            ["alicate universal", '8"', "1 un"],
        )
        self.assertIn("1 un", [item["term"] for item in data["keyword_pool"]])

    def test_user_authorized_commercial_descriptor_can_add_coverage(self):
        intelligence = build_search_intelligence({
            "product": {
                "product_type": ["alicate universal"],
                "attributes": ["bico meia cana", "corte"],
                "quantity": "3 unidades",
            },
            "known_keywords": ["alicate universal", "bico meia cana", "corte", "3 un"],
            "user_authorized_commercial_keywords": ["profissional", "kit"],
        })
        terms = [item["term"].lower() for item in intelligence["keyword_pool"]]
        self.assertIn("profissional", terms)
        self.assertIn("kit", terms)

    def test_user_authorization_never_bypasses_technical_fact_gate(self):
        intelligence = build_search_intelligence({
            "product": {"product_type": "alicate universal"},
            "user_authorized_commercial_keywords": ["profissional", "1000V"],
        })
        rejected = {(item["term"], item["classification"]) for item in intelligence["rejected_keywords"]}
        self.assertIn(("1000V", "UNSUPPORTED"), rejected)
        self.assertIn("profissional", [item["term"].lower() for item in intelligence["keyword_pool"]])

    def test_optimizer_treats_60_as_target_when_real_coverage_reaches_it(self):
        intelligence = build_search_intelligence({
            "product": {
                "product_type": ["alicate universal"],
                "attributes": ["bico meia cana", "corte"],
                "quantity": "3 unidades",
            },
            "known_keywords": ["alicate universal", "bico meia cana", "corte", "3 un"],
            "user_authorized_commercial_keywords": ["profissional", "kit"],
        })
        result = optimize(intelligence)
        self.assertEqual(result["character_count"], 60)
        self.assertEqual(result["title"], "Alicate Universal Bico Meia Cana Corte Profissional Kit 3 Un")
        self.assertEqual(result["remaining_character_analysis"]["status"], "target_reached")
        self.assertIn("profissional", result["title"].lower())

    def test_optimizer_adds_remaining_keywords_that_fit_before_release(self):
        intelligence = build_search_intelligence({
            "product": {
                "product_type": ["jogo catraca"],
                "quantity": "19 pçs",
                "included_items": ["soquetes", "bits"],
                "material": "aço Cr-V",
            },
            "known_keywords": ["jogo", "catraca", "soquete", "bits", "19pçs", "aço", "Cr-V"],
            "user_authorized_commercial_keywords": ["kit", "profissional"],
        })
        result = optimize(intelligence)
        self.assertTrue(result["validation"]["valid"])
        self.assertGreaterEqual(result["character_count"], 55)
        self.assertIn("aço cr-v", result["title"].lower())
        self.assertEqual(result["remaining_character_analysis"]["eligible_incremental_terms_that_fit"], [])

    def test_over_limit_is_rejected(self):
        title = "Furadeira Parafusadeira 20V Impacto 2 Baterias Com Maleta Extra"
        self.assertGreater(len(title), CHARACTER_LIMIT)
        self.assertIn("over_60_characters", validate_title(title)["violations"])

    def test_brand_is_rejected_from_title(self):
        verdict = validate_title("MarcaTeste Parafusadeira 20V", brands=["MarcaTeste"], primary_keywords=["parafusadeira"])
        self.assertIn("contains_brand", verdict["violations"])

    def test_competitor_brand_is_rejected_from_keyword_pool(self):
        data = processed(terms=["parafusadeira", "MarcaConcorrente 20V"], brands=["MarcaConcorrente"])
        self.assertTrue(any(item["classification"] == "BRAND" for item in data["rejected_keywords"]))

    def test_popular_unsupported_attribute_is_rejected(self):
        data = processed(terms=["parafusadeira", "parafusadeira brushless"])
        self.assertTrue(any(item["classification"] == "UNSUPPORTED" for item in data["rejected_keywords"]))

    def test_verified_synonym_can_survive(self):
        data = processed()
        terms = [item["term"] for item in data["keyword_pool"]]
        self.assertIn("furadeira parafusadeira", terms)
        self.assertIn("parafusadeira", terms)

    def test_plural_duplicate_is_removed(self):
        data = processed(terms=["parafusadeira", "parafusadeiras"])
        self.assertTrue(any(item["classification"] == "DUPLICATE" for item in data["rejected_keywords"]))

    def test_observed_compact_unit_variant_wins_same_intent_cluster(self):
        data = processed(
            {"product_type": ["alicate universal"], "dimensions": ["8 Polegadas"]},
            ["alicate universal", "8 Polegadas", '8"'],
        )
        terms = [item["term"] for item in data["keyword_pool"]]
        self.assertIn('8"', terms)
        self.assertNotIn("8 Polegadas", terms)
        self.assertTrue(any(item["reason"] == "equivalent query-intent variant" for item in data["rejected_keywords"]))

    def test_search_relevance_cannot_override_product_truth(self):
        data = processed(
            {"product_type": ["alicate universal"], "dimensions": ["8 Polegadas"]},
            ["alicate universal", "alicate eletricista"],
        )
        self.assertTrue(any(item["term"] == "alicate eletricista" and item["classification"] == "UNSUPPORTED" for item in data["rejected_keywords"]))

    def test_redundant_keyword_in_title_is_rejected(self):
        verdict = validate_title("Furadeira Parafusadeira Parafusadeira 20V")
        self.assertIn("redundant_keyword", verdict["violations"])

    def test_little_material_does_not_force_filler(self):
        data = processed({"product_type": "alicate", "brand": "MarcaTeste"}, ["alicate"])
        candidates = generate_candidates(data)
        self.assertTrue(candidates)
        self.assertLess(len(candidates[0]["title"]), 50)
        self.assertNotIn("premium", candidates[0]["title"].lower())

    def test_many_keywords_are_optimized_under_limit(self):
        candidates = generate_candidates(processed())
        self.assertGreaterEqual(len(candidates), 8)
        self.assertTrue(all(item["character_count"] <= CHARACTER_LIMIT for item in candidates))

    def test_long_tail_is_present_when_verified(self):
        data = processed(terms=["furadeira parafusadeira 20V", "parafusadeira", "20V"])
        self.assertTrue(any(item["classification"] == "LONG_TAIL" for item in data["keyword_pool"]))

    def test_numeric_specification_is_supported(self):
        data = processed()
        self.assertIn("20V", [item["term"] for item in data["keyword_pool"]])

    def test_verified_attributes_are_emitted_as_level_four_evidence(self):
        research = collect_evidence({"product": product()})
        observed = {(item["term"], item["source_level"]) for item in research["evidence"]}
        self.assertIn(("20V", 4), observed)
        self.assertIn(("impacto", 4), observed)

    def test_swap_search_can_choose_non_greedy_order(self):
        candidates = generate_candidates(processed())
        titles = {item["title"] for item in candidates}
        self.assertTrue(any("20V" in title and "maleta" in title.lower() for title in titles))

    def test_overlapping_terms_are_merged_without_repetition(self):
        result = optimize(processed(terms=[
            "furadeira parafusadeira", "parafusadeira", "20V", "impacto",
            "2 baterias", "maleta", "furadeira parafusadeira 20V",
            "parafusadeira impacto", "parafusadeira 2 baterias",
        ]), minimum_characters=0)
        self.assertIn("20V", result["title"])
        self.assertNotIn("parafusadeira parafusadeira", result["title"].lower())

    def test_final_title_starts_with_product_identity(self):
        result = optimize(processed(), minimum_characters=0)
        self.assertTrue(result["title"].lower().startswith(("furadeira", "parafusadeira")))

    def test_shorter_candidate_beats_filler_candidate(self):
        universe = [{"query": "parafusadeira", "weight": 100, "source_level": 3}]
        terms = [{"term": "parafusadeira", "classification": "PRIMARY"}]
        factual = score_candidate("Parafusadeira", universe, terms)
        filler = validate_title("Parafusadeira Premium", primary_keywords=["parafusadeira"])
        self.assertTrue(factual["score"] > 0)
        self.assertFalse(filler["valid"])

    def test_60_characters_can_win_with_real_coverage(self):
        universe = [
            {"query": "parafusadeira", "weight": 100, "source_level": 3},
            {"query": "parafusadeira 20V", "weight": 90, "source_level": 3},
            {"query": "parafusadeira impacto", "weight": 80, "source_level": 3},
        ]
        terms = [
            {"term": "parafusadeira", "classification": "PRIMARY"},
            {"term": "20V", "classification": "SPECIFICATION"},
            {"term": "impacto", "classification": "ATTRIBUTE"},
        ]
        short = score_candidate("Parafusadeira", universe, terms)
        rich = score_candidate("Parafusadeira 20V Impacto", universe, terms)
        self.assertGreater(rich["weighted_query_coverage"], short["weighted_query_coverage"])

    def test_truth_only_attribute_does_not_become_title_filler(self):
        data = processed({"product_type": ["Alicate Universal"], "attributes": ["Cabos Revestidos"], "brand": "X"}, ["Alicate Universal"])
        result = optimize(data, minimum_characters=0)
        self.assertNotIn("Cabos", result["title"])

    def test_research_never_reports_invented_metrics(self):
        research = collect_evidence({"product": product()})
        self.assertIn("No search volume", research["research_limitations"])
        self.assertNotIn("volume", research["evidence"][0])

    def test_observed_meli_language_is_structured_as_search_intelligence(self):
        intelligence = build_search_intelligence({
            "product": {"product_type": ["jogo chave catraca"], "quantity": "19 peças", "included_items": ["soquetes", "bits"]},
            "meli_observations": {
                "results": ["Jogo Chave Catraca Mini Soquetes Bits 19 Peças"],
                "source_url": "https://lista.mercadolivre.com.br/jogo-catraca",
            },
        })
        query = next(item for item in intelligence["query_universe"] if "soquetes" in item["query"].lower())
        self.assertEqual(query["evidence_level"], 2)
        self.assertIn(query["tail"], {"mid_tail", "long_tail"})
        self.assertTrue(query["cluster"])
        self.assertEqual(intelligence["fallback_level"], 2)

    def test_low_value_token_from_competitor_title_is_not_promoted_as_keyword(self):
        research = collect_evidence({
            "product": {"product_type": "jogo catraca", "color": "amarelo"},
            "meli_observations": {"results": ["Jogo Catraca Amarelo Profissional"]},
        })
        promoted = [
            item for item in research["evidence"]
            if item["term"].lower() == "amarelo" and item["source"] != "verified_product_fact"
        ]
        self.assertEqual(promoted, [])

    def test_search_evidence_changes_weighted_coverage_without_overriding_truth(self):
        product_data = {
            "product_type": ["jogo chave catraca"],
            "quantity": "19 peças",
            "included_items": ["soquetes", "bits"],
        }
        observed = collect_evidence({
            "product": product_data,
            "meli_observations": {"results": ["Jogo Chave Catraca Mini Soquetes Bits 19 Peças"]},
        })
        data = build_keyword_pool(product_data, observed["evidence"])
        data["query_universe"] = build_query_universe(data["keyword_pool"])
        result = optimize(data, minimum_characters=0)
        self.assertIn("soquetes", result["title"].lower())
        self.assertTrue(any(item["source_level"] == 2 for item in data["query_universe"]))

    def test_exact_product_public_evidence_enriches_truth_but_comparable_listing_does_not(self):
        intelligence = build_search_intelligence({
            "product": {"product_type": "alicate universal", "dimensions": ['8"']},
            "external_product_evidence": [
                {"term": "segurar peças", "field": "functions", "product_match": "exact", "source_url": "https://example.test/exato"},
                {"term": "isolado 1000V", "field": "specifications", "product_match": "comparable", "source_url": "https://example.test/similar"},
            ],
        })
        facts = intelligence["product_facts"]["raw"]
        self.assertIn("segurar peças", facts["functions"])
        self.assertNotIn("isolado 1000V", " ".join(facts.get("specifications", [])))
        self.assertTrue(any(item["term"] == "isolado 1000V" for item in intelligence["rejected_external_evidence"]))

    def test_query_universe_labels_short_mid_and_long_tail(self):
        data = processed(terms=["parafusadeira", "parafusadeira 20V", "furadeira parafusadeira 20V impacto"])
        tails = {item["tail"] for item in data["query_universe"]}
        self.assertIn("short_tail", tails)
        self.assertIn("mid_tail", tails)
        self.assertIn("long_tail", tails)

    def test_overlapping_phrases_do_not_leave_a_dangling_connector(self):
        product_data = {
            "product_type": ["jogo chave catraca", "jogo de soquetes e bits"],
            "quantity": "19 peças",
            "included_items": ["chave catraca", "soquetes", "bits"],
        }
        research = collect_evidence({
            "product": product_data,
            "meli_observations": {"results": ["Jogo Chave Catraca 19 Peças Soquetes E Bits"]},
        })
        data = build_keyword_pool(product_data, research["evidence"])
        data["query_universe"] = build_query_universe(data["keyword_pool"])
        title = optimize(data, minimum_characters=0)["title"].lower()
        self.assertNotIn(title.split()[-1], {"de", "da", "do", "e", "para", "com"})


if __name__ == "__main__":
    unittest.main()
