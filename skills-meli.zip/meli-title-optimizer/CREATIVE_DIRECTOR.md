# Creative Director — Contrato MeLi

## Autoridade factual

A solicitação e as correções atuais do usuário prevalecem. Fotografias,
documentos e embalagem confirmam identidade, componentes, quantidade, medidas,
materiais e funções. Produtos similares servem somente para pesquisa de
linguagem e intenção; nunca transferem especificações ao produto anunciado.

Não invente fatos, certificações, garantias, avaliações, estatísticas,
compatibilidades ou itens inclusos.

## Título

O título é responsabilidade exclusiva da `meli-title-optimizer`:

- Mercado Livre Brasil;
- 58–60 caracteres;
- factual e natural;
- sem marca;
- baseado nas palavras-chave do usuário e em pesquisa no Mercado Livre;
- resultado aprovado preservado sem reescrita.

## Descrição

A descrição deve ter 1.200–1.500 caracteres úteis, ser comercial, factual e
escaneável. Deve cobrir somente quando comprovado: finalidade, benefício
prático, conteúdo, funções, medidas, materiais, aplicações, compatibilidade,
operação, organização, cuidados, limitações e não inclusos.

## Estrutura de arquivos

Depois de aprovar o título, use exatamente esse texto como nome da pasta
comercial:

`Produtos/<TÍTULO APROVADO>/`

Use também o mesmo título, sem reescrita, nos nomes das imagens:

- `01 - <TÍTULO APROVADO>.png`
- `02 - <TÍTULO APROVADO>.png`
- continue a numeração até a última imagem da galeria.

Dentro da pasta comercial, salve somente um arquivo de texto:

`Descrição.txt`

`Descrição.txt` deve conter exclusivamente a descrição comercial aprovada. Não
inclua título, rótulo como `Título:`, nome da pasta, contagem de caracteres,
metadados, relatório, prompt ou qualquer outro conteúdo no arquivo.

Não crie `Título.txt`, `Anúncio.txt` nem arquivo combinado de título e
descrição. O título já está representado pelo nome da pasta e pelos nomes das
imagens.

## Imagens

O Creative Director não cria, complementa nem interpreta regras visuais. Ao
invocar `oferta-meli`, a geração de imagens é regida exclusivamente pelo
contrato presente em:

`.agents/skills/oferta-meli/SKILL.md`

Texto e tipografia seguem exclusivamente as imagens de:

`Produtos/Alicate Universal 8 Isolado 1000V Aço Cr-V para Eletricista/`

Nenhuma regra visual histórica deste projeto deve ser recuperada ou combinada
com esse contrato.
