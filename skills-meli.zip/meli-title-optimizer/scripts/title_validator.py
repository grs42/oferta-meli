"""Deterministic hard gates for Mercado Livre Brasil titles."""

from __future__ import annotations

import re
import unicodedata
from collections import Counter
from typing import Any, Iterable


CHARACTER_LIMIT = 60
MIN_CHARACTER_TARGET = 58
FILLER_TERMS = {"produto", "qualidade", "ideal", "excelente", "super", "premium"}
FUNCTION_WORDS = {"a", "o", "as", "os", "de", "da", "das", "do", "dos", "e", "em", "para", "com"}


def normalize(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", value).strip()


def count_characters(title: str) -> int:
    return len(title)


def contains_brand(title: str, brands: Iterable[str]) -> bool:
    normalized_title = f" {normalize(title)} "
    return any(brand and f" {normalize(brand)} " in normalized_title for brand in brands)


def contains_filler(title: str) -> bool:
    return bool(set(normalize(title).split()) & FILLER_TERMS)


def contains_redundant_keyword(title: str) -> bool:
    """Reject repeated meaningful tokens; connector words are not keywords."""
    counts = Counter(token for token in normalize(title).split() if token not in FUNCTION_WORDS)
    return any(count > 1 for count in counts.values())


def validate_title(
    title: str,
    *,
    brands: Iterable[str] = (),
    primary_keywords: Iterable[str] = (),
    forbidden_terms: Iterable[str] = (),
    min_characters: int = MIN_CHARACTER_TARGET,
) -> dict[str, Any]:
    normalized = normalize(title)
    primary = [normalize(item) for item in primary_keywords if normalize(item)]
    forbidden = [normalize(item) for item in forbidden_terms if normalize(item)]
    violations: list[str] = []
    if not title.strip():
        violations.append("empty_title")
    if count_characters(title) > CHARACTER_LIMIT:
        violations.append("over_60_characters")
    if count_characters(title) < min_characters:
        violations.append(f"below_{min_characters}_characters")
    if contains_brand(title, brands):
        violations.append("contains_brand")
    if any(f" {item} " in f" {normalized} " for item in forbidden):
        violations.append("contains_forbidden_term")
    if contains_filler(title):
        violations.append("contains_filler")
    if contains_redundant_keyword(title):
        violations.append("redundant_keyword")
    if primary and not any(item in normalized for item in primary):
        violations.append("missing_primary_keyword")
    return {
        "title": title,
        "character_count": count_characters(title),
        "character_limit": CHARACTER_LIMIT,
        "character_floor_used_for_candidate_search": min_characters,
        "brand_free": "contains_brand" not in violations,
        "within_limit": "over_60_characters" not in violations,
        "meets_character_target": f"below_{min_characters}_characters" not in violations,
        "valid": not violations,
        "violations": violations,
    }


def validate_release_title(
    title: str,
    *,
    brands: Iterable[str] = (),
    primary_keywords: Iterable[str] = (),
    forbidden_terms: Iterable[str] = (),
    eligible_incremental_terms_that_fit: Iterable[str] = (),
    require_research: bool = False,
    research_provenance: Iterable[dict[str, Any]] = (),
) -> dict[str, Any]:
    """Validate the immutable title used by the exported offer.

    Production titles are restricted to 58–60 characters. Research provenance
    is also required when the caller is performing a production release.
    """
    result = validate_title(
        title,
        brands=brands,
        primary_keywords=primary_keywords,
        forbidden_terms=forbidden_terms,
        min_characters=MIN_CHARACTER_TARGET,
    )
    fitting = [str(item).strip() for item in eligible_incremental_terms_that_fit if str(item).strip()]
    if fitting:
        result["violations"].append("unused_eligible_incremental_term")
        result["valid"] = False
    result["eligible_incremental_terms_that_fit"] = fitting
    provenance = [item for item in research_provenance if isinstance(item, dict)]
    research_valid = bool(provenance) and all(
        str(item.get("surface", "")).startswith("meli")
        and str(item.get("query", "")).strip()
        and str(item.get("url", "")).startswith("https://")
        and bool(item.get("observed_terms"))
        for item in provenance
    )
    if require_research and not research_valid:
        result["violations"].append("missing_meli_research_provenance")
        result["valid"] = False
    result["research_verified"] = research_valid
    result["character_target"] = CHARACTER_LIMIT
    return result
