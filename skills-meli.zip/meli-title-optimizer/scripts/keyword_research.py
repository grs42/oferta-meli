"""Collect only auditable keyword evidence for Mercado Livre Brasil.

This module deliberately does not scrape, rank, or invent search metrics. An
agent or caller supplies suggestions, observed Mercado Livre results, category
attributes, or known keywords with their real source; this script structures
those observations for the optimizer.
"""

from __future__ import annotations

import argparse
import copy
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


def normalize(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", value.lower()).strip()


def _words(value: str) -> list[str]:
    return re.findall(r"[\wÀ-ÿ]+", value.lower())


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple, set)):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)]


def _product_seeds(product: dict[str, Any]) -> list[str]:
    # Product type/category are facts supplied by the calling skill, not demand.
    return _as_list(product.get("product_type")) + _as_list(product.get("category"))


def _verified_product_terms(product: dict[str, Any]) -> list[str]:
    """Expose confirmed, title-eligible facts as level-4 evidence.

    These are not market signals. They merely let the later stages test factual
    attributes against demand evidence instead of silently losing them.
    """
    fields = (
        "product_type", "category", "attributes", "specifications", "features",
        "use_cases", "included_items", "dimensions", "material", "color",
        "quantity", "compatibility", "additional_verified_facts", "functions",
    )
    terms: list[str] = []
    for field in fields:
        terms.extend(_as_list(product.get(field)))
    return terms


_EXTERNAL_FACT_FIELDS = {
    "attributes", "specifications", "features", "use_cases", "included_items",
    "dimensions", "material", "quantity", "compatibility",
    "additional_verified_facts", "functions",
}


def enrich_product_with_public_evidence(payload: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, str]], list[dict[str, str]]]:
    """Add auditable public facts only when their product match is exact.

    Comparable listings remain market-language research and cannot transfer a
    specification to the advertised item.
    """
    product = copy.deepcopy(payload.get("product", {}))
    accepted: list[dict[str, str]] = []
    rejected: list[dict[str, str]] = []
    for item in payload.get("external_product_evidence", ()) or ():
        term = str(item.get("term", "")).strip() if isinstance(item, dict) else ""
        field = str(item.get("field", "")).strip() if isinstance(item, dict) else ""
        url = str(item.get("source_url", "")).strip() if isinstance(item, dict) else ""
        match = str(item.get("product_match", "")).casefold().strip() if isinstance(item, dict) else ""
        if not term:
            rejected.append({"term": term, "reason": "empty_term"})
        elif match != "exact":
            rejected.append({"term": term, "reason": "not_exact_product_match"})
        elif field not in _EXTERNAL_FACT_FIELDS:
            rejected.append({"term": term, "reason": "unsupported_fact_field"})
        elif not url:
            rejected.append({"term": term, "reason": "missing_source_url"})
        else:
            values = _as_list(product.get(field))
            if term not in values:
                values.append(term)
            product[field] = values
            accepted.append({"term": term, "field": field, "source_url": url})
    return product, accepted, rejected


def _competitor_titles(results: Iterable[Any]) -> list[str]:
    titles: list[str] = []
    for item in results or []:
        if isinstance(item, str):
            titles.append(item)
        elif isinstance(item, dict) and item.get("title"):
            titles.append(str(item["title"]))
    return titles


def _observed_fact_phrases(product: dict[str, Any], titles: Iterable[str]) -> list[str]:
    """Keep only Product Truth phrases actually seen in public result language.

    A word occurring in a competitor title is not automatically a search keyword.
    This deliberately avoids promoting incidental visual descriptors such as colour
    from a single listing. Suggestions remain stronger level-1 evidence.
    """
    fields = (
        "product_type", "category", "attributes", "specifications", "features",
        "use_cases", "included_items", "dimensions", "quantity", "compatibility",
        "additional_verified_facts",
    )
    facts = [phrase for field in fields for phrase in _as_list(product.get(field))]
    observed = normalize(" ".join(titles))
    return [phrase for phrase in facts if normalize(phrase) and normalize(phrase) in observed]


def collect_evidence(payload: dict[str, Any]) -> dict[str, Any]:
    """Return source-labelled evidence without claiming unavailable metrics.

    Source levels follow the skill contract:
    1 = observed Mercado Livre suggestions/results supplied with provenance;
    2 = Mercado Livre titles/category attributes supplied with provenance;
    3 = user/caller keywords; 4 = linguistic seeds from product facts.
    """
    product, accepted_external, rejected_external = enrich_product_with_public_evidence(payload)
    observed = payload.get("meli_observations", {})
    source_url = str(observed.get("source_url", "")).strip()
    source_surface = str(observed.get("surface", "meli_search")).strip()
    source_query = str(observed.get("query", "")).strip()
    observed_terms = _as_list(observed.get("suggestions")) + _competitor_titles(observed.get("results", ()))
    research_provenance = []
    if source_url and source_query and observed_terms:
        research_provenance.append({
            "surface": source_surface,
            "query": source_query,
            "url": source_url,
            "observed_terms": observed_terms,
            "observed_at": str(observed.get("observed_at", "")).strip(),
        })
    evidence: list[dict[str, Any]] = []

    for seed in _product_seeds(product):
        evidence.append({"term": seed, "source_level": 4, "source": "product_fact_seed"})

    for term in _verified_product_terms(product):
        evidence.append({"term": term, "source_level": 4, "source": "verified_product_fact"})
    for item in accepted_external:
        evidence.append({"term": item["term"], "source_level": 3, "source": "public_exact_product_fact"})

    for term in _as_list(payload.get("known_keywords")):
        evidence.append({"term": term, "source_level": 3, "source": "caller_keyword"})

    # A caller can explicitly authorize a non-technical commercial descriptor
    # (for example, "profissional") for title testing.  The processor still
    # blocks brands and technical/specification-looking claims.
    for term in _as_list(payload.get("user_authorized_commercial_keywords")):
        evidence.append({
            "term": term,
            "source_level": 3,
            "source": "user_authorized_commercial_keyword",
            "authorization": "commercial_descriptor",
        })

    for term in _as_list(observed.get("suggestions")):
        evidence.append({"term": term, "source_level": 1, "source": "meli_observed_suggestion"})

    for term in _as_list(observed.get("category_attributes")) + _as_list(payload.get("category_attributes")):
        evidence.append({"term": term, "source_level": 2, "source": "meli_category_attribute"})

    titles = _competitor_titles(observed.get("results") or payload.get("competitor_results"))
    token_frequency = Counter(word for title in titles for word in _words(title))
    for title in titles:
        evidence.append({"term": title, "source_level": 2, "source": "meli_result_title"})
    # Exact, confirmed phrases observed in results are valid marketplace language.
    # Individual tokens are retained only as audit frequency, never promoted to
    # title candidates by themselves.
    for phrase in _observed_fact_phrases(product, titles):
        evidence.append({
            "term": phrase,
            "source_level": 2,
            "source": "meli_result_fact_phrase",
        })

    return {
        "seeds": _product_seeds(product),
        "evidence": evidence,
        "competitor_titles": titles,
        "competitor_token_frequency": dict(token_frequency),
        "research_limitations": (
            "No search volume, ranking, CPC, sales, or trend is inferred. "
            "Frequency exists only when observed Mercado Livre result titles were supplied."
        ),
        "research_hierarchy": [
            "observed_meli_surface",
            "observed_meli_results",
            "caller_keywords",
            "product_truth_only",
        ],
        "enriched_product": product,
        "accepted_external_evidence": accepted_external,
        "rejected_external_evidence": rejected_external,
        "research_provenance": research_provenance,
        "research_verified": bool(research_provenance),
    }


def build_search_intelligence(payload: dict[str, Any]) -> dict[str, Any]:
    """Return an auditable query universe built from the available evidence.

    Browser/web collection itself belongs to the calling agent. This function
    makes supplied public Mercado Livre observations operational in ranking,
    while recording the fallback level instead of fabricating metrics.
    """
    from keyword_processor import build_keyword_pool, build_query_universe

    research = collect_evidence(payload)
    pool = build_keyword_pool(
        research["enriched_product"], research["evidence"], payload.get("observed_brands", ())
    )
    universe = build_query_universe(pool["keyword_pool"])
    source_levels = [item["source_level"] for item in pool["keyword_pool"]]
    return {
        **research,
        **pool,
        "query_universe": universe,
        "fallback_level": min(source_levels) if source_levels else 4,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path, help="JSON payload with product and observed evidence")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = collect_evidence(json.loads(args.input.read_text(encoding="utf-8")))
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
