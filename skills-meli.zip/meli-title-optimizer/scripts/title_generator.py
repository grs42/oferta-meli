"""Generate and score fact-gated Mercado Livre title candidates."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
from typing import Any, Iterable

from keyword_processor import build_query_universe, canonical
from title_validator import CHARACTER_LIMIT, MIN_CHARACTER_TARGET, validate_release_title, validate_title


CONNECTORS = {"a", "as", "o", "os", "de", "da", "das", "do", "dos", "e", "em", "para", "com"}


def _tokens(value: str) -> set[str]:
    return set(canonical(value).split())


def _covers(title: str, query: str) -> bool:
    return _tokens(query).issubset(_tokens(title))


def _unique_terms(items: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    result = []
    for item in items:
        key = item["normalized"]
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def _merge_terms(items: Iterable[dict[str, Any]]) -> str:
    """Join overlapping queries without paying twice for the same token."""
    output: list[str] = []
    seen: set[str] = set()
    for item in items:
        new_tokens = [token for token in item["term"].split() if canonical(token) not in seen]
        # A fully covered phrase may contribute only a connector (for example
        # "de" after its meaningful words already exist). It has no search
        # coverage and would leave an unreadable title fragment.
        if new_tokens and not any(canonical(token) not in CONNECTORS for token in new_tokens):
            continue
        for token in new_tokens:
            key = canonical(token)
            if key not in seen:
                seen.add(key)
                output.append(token)
    return " ".join(output)


def _semantic_order_penalty(items: Iterable[dict[str, Any]]) -> int:
    """Prefer a readable commercial sequence without adding a title template."""
    ranks: list[int] = []
    for item in items:
        term = canonical(item["term"])
        if item["classification"] == "PRIMARY":
            rank = 0
        elif term == "kit":
            rank = 3
        elif item.get("authorization") == "commercial_descriptor":
            rank = 2
        elif any(character.isdigit() for character in item["term"]):
            rank = 4
        else:
            rank = 1
        ranks.append(rank)
    return sum(max(0, left - right) for left, right in zip(ranks, ranks[1:]))


def _phrase_cohesion(title: str, terms: Iterable[dict[str, Any]]) -> int:
    """Reward natural verified phrases over scrambled token-equivalent forms."""
    normalized_title = f" {canonical(title)} "
    return sum(
        1 for item in terms
        if len(canonical(item["term"]).split()) > 1
        and f" {canonical(item['term'])} " in normalized_title
    )


def _display_title(value: str) -> str:
    """Apply buyer-facing capitalization while preserving compact numeric facts."""
    words = []
    for word in value.split():
        if any(character.isdigit() for character in word) or word in CONNECTORS:
            words.append(word)
        elif word.isupper() and len(word) > 1:
            words.append(word)
        else:
            words.append(word.capitalize())
    return " ".join(words)


def score_candidate(title: str, query_universe: Iterable[dict[str, Any]], terms: Iterable[dict[str, Any]]) -> dict[str, Any]:
    queries = list(query_universe)
    term_items = list(terms)
    covered = [query for query in queries if _covers(title, query["query"])]
    total_weight = sum(query["weight"] for query in queries) or 1
    weighted_coverage = sum(query["weight"] for query in covered) / total_weight
    classifications = {term["classification"] for term in term_items if _covers(title, term["term"])}
    primary_secondary = ("PRIMARY" in classifications) + ("SECONDARY" in classifications or "SYNONYM" in classifications)
    primary_secondary_score = primary_secondary / 2
    market_signal = sum(1 for query in covered if query["source_level"] <= 2) / max(len(covered), 1)
    char_count = len(title)
    efficiency = weighted_coverage / max(char_count / CHARACTER_LIMIT, 0.15)
    utilization = char_count / CHARACTER_LIMIT
    primary_terms = [item["term"].lower() for item in term_items if item["classification"] == "PRIMARY"]
    starts_with_identity = any(title.lower().startswith(term) for term in primary_terms)
    readability = 1.0 if title == " ".join(title.split()) and "  " not in title and starts_with_identity else 0.5
    attribute_score = sum(1 for kind in classifications if kind in {"ATTRIBUTE", "SPECIFICATION", "COMPATIBILITY", "USE_CASE"}) / 4
    # Utilization is only a tie-breaker for real coverage. It cannot compensate
    # for low-value words merely because they approach the 60-character budget.
    score = (0.35 * weighted_coverage + 0.20 * primary_secondary_score + 0.15 * market_signal +
             0.15 * min(efficiency, 1) + 0.05 * utilization + 0.05 * readability + 0.05 * attribute_score)
    return {
        "title": title, "character_count": char_count, "score": round(score, 6),
        "covered_queries": [item["query"] for item in covered],
        "weighted_query_coverage": round(weighted_coverage, 6),
        "character_efficiency": round(efficiency, 6),
    }


def generate_candidates(
    processed: dict[str, Any], *, limit: int = 15, min_characters: int = 0
) -> list[dict[str, Any]]:
    pool = _unique_terms(processed["keyword_pool"])
    primary = [item for item in pool if item["classification"] == "PRIMARY"]
    if not primary:
        return []
    # A fact is eligible, but it only spends title characters when it has
    # external/search evidence. Product-truth-only attributes remain available
    # to the description and gallery instead of becoming automatic title filler.
    additions = [
        item for item in pool
        if item["classification"] != "PRIMARY" and item["source_level"] <= 3
    ][:10]
    universe = processed.get("query_universe") or build_query_universe(pool)
    brands = processed["product_facts"].get("brands", [])
    candidates: dict[str, dict[str, Any]] = {}

    # Exhaustive bounded combinations make swap optimisation deterministic rather
    # than relying on a greedy append-only result.
    for base in primary[:3]:
        options = [base] + additions
        for width in range(1, min(6, len(options)) + 1):
            for combo in itertools.combinations(options, width):
                if base not in combo:
                    continue
                for ordered in itertools.permutations(combo):
                    title = _merge_terms(ordered)
                    validation = validate_title(
                        title,
                        brands=brands,
                        primary_keywords=[item["term"] for item in primary],
                        min_characters=min_characters,
                    )
                    if not validation["valid"]:
                        continue
                    scored = score_candidate(title, universe, pool)
                    scored["semantic_order_penalty"] = _semantic_order_penalty(ordered)
                    scored["validation"] = validation
                    prior = candidates.get(title)
                    if prior is None or scored["score"] > prior["score"]:
                        candidates[title] = scored

    ordered = sorted(candidates.values(), key=lambda item: (-item["score"], -item["character_count"], item["title"]))
    return ordered[:max(limit, 8)]


def optimize(processed: dict[str, Any], *, minimum_characters: int = MIN_CHARACTER_TARGET) -> dict[str, Any]:
    processed = dict(processed)
    processed["query_universe"] = processed.get("query_universe") or build_query_universe(processed["keyword_pool"])
    candidates = generate_candidates(processed, limit=120, min_characters=0)
    if not candidates:
        return {
            "title": "",
            "character_count": 0,
            "character_limit": CHARACTER_LIMIT,
            "character_target": CHARACTER_LIMIT,
            "validation": {"valid": False, "violations": ["no_factual_title_candidate"]},
            "top_candidates": [],
        }
    # Only exact-budget candidates reach this point. Coverage still decides the
    # winner, so the 60-character requirement never authorizes filler.
    best = max(
        candidates,
        key=lambda item: (
            item["weighted_query_coverage"],
            len(item["covered_queries"]),
            _phrase_cohesion(item["title"], processed["keyword_pool"]),
            -item["semantic_order_penalty"],
            item["score"],
            item["character_count"],
        ),
    )
    best = dict(best)
    best["title"] = _display_title(best["title"])
    # Candidate generation is deliberately bounded. After choosing the best
    # semantic base, spend any remaining characters on factual terms that add
    # query coverage. This closes the gap where a useful short keyword still
    # fit but the bounded combination width left it behind.
    while True:
        current_title = best["title"]
        current_queries = {
            query["query"] for query in processed["query_universe"]
            if _covers(current_title, query["query"])
        }
        expansions: list[dict[str, Any]] = []
        for item in processed["keyword_pool"]:
            if _tokens(item["term"]).issubset(_tokens(current_title)):
                continue
            merged = _display_title(_merge_terms([{"term": current_title}, item]))
            if len(merged) > CHARACTER_LIMIT:
                continue
            validation = validate_title(
                merged,
                brands=processed["product_facts"].get("brands", []),
                primary_keywords=[term["term"] for term in processed["keyword_pool"] if term["classification"] == "PRIMARY"],
                min_characters=0,
            )
            if not validation["valid"]:
                continue
            newly_covered = [
                query for query in processed["query_universe"]
                if query["query"] not in current_queries and _covers(merged, query["query"])
            ]
            if not newly_covered:
                continue
            expansions.append({
                "title": merged,
                "gain": sum(query["weight"] for query in newly_covered),
                "score": score_candidate(merged, processed["query_universe"], processed["keyword_pool"])["score"],
            })
        if not expansions:
            break
        chosen = max(expansions, key=lambda item: (item["gain"], item["score"], len(item["title"])))
        best["title"] = chosen["title"]

    refreshed = score_candidate(best["title"], processed["query_universe"], processed["keyword_pool"])
    best.update(refreshed)
    # Candidate exploration may use a relaxed threshold, but export never does.
    used = set(_tokens(best["title"]))
    excluded = [item["term"] for item in processed["keyword_pool"] if not _tokens(item["term"]).issubset(used)]
    remaining = CHARACTER_LIMIT - best["character_count"]
    fitting_terms = []
    for item in processed["keyword_pool"]:
        if _tokens(item["term"]).issubset(used):
            continue
        merged = _merge_terms([
            {"term": best["title"]},
            item,
        ])
        if len(merged) <= CHARACTER_LIMIT and any(
            _covers(merged, query["query"]) and not _covers(best["title"], query["query"])
            for query in processed["query_universe"]
        ):
            fitting_terms.append(item["term"])
    remaining_analysis = {
        "target": CHARACTER_LIMIT,
        "current": best["character_count"],
        "remaining": remaining,
        "status": "target_reached" if remaining == 0 else "no_eligible_incremental_coverage_fits",
        "eligible_incremental_terms_that_fit": fitting_terms,
    }
    best["validation"] = validate_release_title(
        best["title"],
        brands=processed["product_facts"].get("brands", []),
        primary_keywords=[item["term"] for item in processed["keyword_pool"] if item["classification"] == "PRIMARY"],
        eligible_incremental_terms_that_fit=fitting_terms,
    )
    return {
        "title": best["title"],
        "character_count": best["character_count"],
        "character_limit": CHARACTER_LIMIT,
        "character_target": CHARACTER_LIMIT,
        "primary_keyword": next(item["term"] for item in processed["keyword_pool"] if item["classification"] == "PRIMARY"),
        "covered_queries": best["covered_queries"],
        "covered_terms": [item["term"] for item in processed["keyword_pool"] if _covers(best["title"], item["term"])],
        "excluded_high_value_terms": excluded[:10],
        "remaining_character_analysis": remaining_analysis,
        "validation": best["validation"],
        "score": best["score"],
        "top_candidates": candidates[:15],
    }


def optimize_for_release(processed: dict[str, Any]) -> dict[str, Any]:
    """Optimize and enforce production research plus the 58–60 range."""
    result = optimize(processed, minimum_characters=MIN_CHARACTER_TARGET)
    provenance = processed.get("research_provenance", ())
    fitting = result.get("remaining_character_analysis", {}).get(
        "eligible_incremental_terms_that_fit", ()
    )
    result["research_provenance"] = list(provenance)
    result["validation"] = validate_release_title(
        result.get("title", ""),
        brands=processed.get("product_facts", {}).get("brands", ()),
        primary_keywords=[
            item["term"] for item in processed.get("keyword_pool", ())
            if item.get("classification") == "PRIMARY"
        ],
        eligible_incremental_terms_that_fit=fitting,
        require_research=True,
        research_provenance=provenance,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path, help="processed keyword-pool JSON")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = optimize(json.loads(args.input.read_text(encoding="utf-8")))
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
