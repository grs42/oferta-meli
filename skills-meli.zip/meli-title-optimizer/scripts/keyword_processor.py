"""Normalize and fact-gate Mercado Livre title keywords."""

from __future__ import annotations

import re
import unicodedata
from collections import defaultdict
from typing import Any, Iterable


TAXONOMY = {"PRIMARY", "SECONDARY", "ATTRIBUTE", "SPECIFICATION", "USE_CASE", "COMPATIBILITY", "SYNONYM", "LONG_TAIL"}
REJECTED = {"BRAND", "UNSUPPORTED", "IRRELEVANT", "DUPLICATE", "LOW_VALUE"}

# Explicit user direction can authorize a broad commercial descriptor, but it
# never turns a technical, safety, material, capacity, or compatibility claim
# into Product Truth.  Numeric units are deliberately excluded here; their
# compact spelling remains available only when the underlying fact is known.
_TECHNICAL_OR_SPECIFIC_CLAIM = re.compile(
    r"\d|\b(aco|aluminio|cromo|vanadio|isolado|isolamento|volt|volts|v|ampere|"
    r"amperes|watt|watts|torque|antiderrapante|impermeavel|resistente|"
    r"compat[ií]vel|universal|profissional eletricista)\b",
    re.IGNORECASE,
)


def normalize(value: str) -> str:
    text = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def canonical(value: str) -> str:
    """Collapse trivial plural variation while preserving multiword intent."""
    words = []
    for word in normalize(value).split():
        words.append(word[:-1] if len(word) > 3 and word.endswith("s") else word)
    return " ".join(words)


# These are neutral unit spellings, not product/category rules.  They let the
# optimizer compare two *observed* ways of expressing the same measurement
# without treating the longer spelling as a new search intention.
_UNIT_EQUIVALENTS = {
    "unidade": "un", "unidades": "un", "und": "un",
    "polegada": "in", "polegadas": "in",
    "milimetro": "mm", "milimetros": "mm",
    "centimetro": "cm", "centimetros": "cm",
    "metro": "m", "metros": "m",
}


def semantic_cluster(value: str) -> str:
    """Key equivalent spelling/unit variants to one query-intent cluster."""
    # Preserve the meaning of the inch symbol before generic punctuation
    # normalization discards it (for example, 8\" and 8 polegadas).
    expanded = re.sub(r"(\d+)\s*[\"″]", r"\1 in", str(value))
    return " ".join(_UNIT_EQUIVALENTS.get(word, word) for word in canonical(expanded).split())


def _values(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, dict):
        return [f"{key} {item}" for key, item in value.items() if item not in (None, False, "")]
    if isinstance(value, (list, tuple, set)):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)]


def product_facts(product: dict[str, Any]) -> dict[str, Any]:
    allowed_fields = (
        "product_type", "category", "attributes", "specifications", "features",
        "use_cases", "included_items", "dimensions", "material", "color",
        "quantity", "compatibility", "additional_verified_facts", "functions",
    )
    phrases: list[str] = []
    for field in allowed_fields:
        phrases.extend(_values(product.get(field)))
    normalized = {canonical(phrase) for phrase in phrases if canonical(phrase)}
    brands = {canonical(item) for item in _values(product.get("brand")) + _values(product.get("manufacturer"))}
    return {"phrases": sorted(normalized), "brands": sorted(brands), "raw": product}


def _token_set(value: str) -> set[str]:
    # Compact units are equivalent spellings of one confirmed fact, not a new
    # claim: e.g. a user-approved "1 un" may stand for "1 unidade".
    return set(semantic_cluster(value).split())


def supported_by_facts(term: str, facts: dict[str, Any], primary_terms: Iterable[str]) -> bool:
    candidate = _token_set(term)
    if not candidate:
        return False
    allowed = set().union(*(_token_set(item) for item in facts["phrases"]), set())
    allowed.update(*( _token_set(item) for item in primary_terms))
    return candidate.issubset(allowed)


def is_user_authorized_commercial_descriptor(item: dict[str, Any]) -> bool:
    """Allow a caller-approved commercial modifier without promoting specs."""
    if item.get("source") != "user_authorized_commercial_keyword":
        return False
    if item.get("authorization") != "commercial_descriptor":
        return False
    return not _TECHNICAL_OR_SPECIFIC_CLAIM.search(str(item.get("term", "")))


def classify_term(term: str, facts: dict[str, Any], primary_terms: list[str], source: str = "", *, user_authorized: bool = False) -> tuple[str, str]:
    normalized = canonical(term)
    if not normalized:
        return "IRRELEVANT", "empty"
    brands = set(facts["brands"])
    if any(brand and brand in normalized for brand in brands):
        return "BRAND", "brand term"
    if not supported_by_facts(normalized, facts, primary_terms) and not user_authorized:
        return "UNSUPPORTED", "not whitelisted by product facts"
    if normalized in {canonical(item) for item in primary_terms}:
        return "PRIMARY", "product identity"
    if len(normalized.split()) > 2:
        return "LONG_TAIL", "verified multi-concept phrase"
    if user_authorized:
        return "ATTRIBUTE", "explicit user-authorized commercial descriptor"
    return "ATTRIBUTE", source or "verified product fact"


def priority(term: str, kind: str, source_level: int, market_frequency: int = 0) -> float:
    base = {"PRIMARY": 100, "SECONDARY": 82, "SPECIFICATION": 78, "ATTRIBUTE": 66,
            "COMPATIBILITY": 63, "USE_CASE": 55, "SYNONYM": 54, "LONG_TAIL": 75}.get(kind, 0)
    source_bonus = {1: 12, 2: 8, 3: 4, 4: 0}.get(source_level, 0)
    cost = max(len(term), 1)
    return round((base + source_bonus + min(market_frequency, 20)) / (1 + cost / 40), 4)


def build_keyword_pool(product: dict[str, Any], evidence: Iterable[dict[str, Any]], observed_brands: Iterable[str] = ()) -> dict[str, Any]:
    facts = product_facts(product)
    facts["brands"] = sorted(set(facts["brands"]) | {canonical(item) for item in observed_brands if canonical(item)})
    primary_terms = _values(product.get("product_type"))
    dedup: dict[str, dict[str, Any]] = {}
    rejected: list[dict[str, Any]] = []
    source_counts: defaultdict[str, int] = defaultdict(int)

    for item in evidence:
        term = str(item.get("term", ""))
        key = semantic_cluster(term)
        kind, reason = classify_term(
            term,
            facts,
            primary_terms,
            str(item.get("source", "")),
            user_authorized=is_user_authorized_commercial_descriptor(item),
        )
        if kind in REJECTED:
            rejected.append({"term": term, "classification": kind, "reason": reason})
            continue
        if key in dedup:
            existing = dedup[key]
            level = int(item.get("source_level", 4))
            # Prefer stronger evidence; at equal evidence, retain the concise
            # observed representation.  This does not invent abbreviations.
            replace = (level < existing["source_level"] or
                       (level == existing["source_level"] and len(term.strip()) < len(existing["term"])))
            if replace:
                rejected.append({"term": existing["term"], "classification": "DUPLICATE", "reason": "equivalent query-intent variant"})
                dedup[key] = {
                    "term": term.strip(), "normalized": canonical(term), "classification": kind,
                    "source_level": level, "source": item.get("source", "unknown"),
                    "authorization": item.get("authorization"),
                    "market_frequency": max(existing.get("market_frequency", 0), int(item.get("market_frequency", 0))),
                }
            else:
                existing["market_frequency"] = max(existing.get("market_frequency", 0), int(item.get("market_frequency", 0)))
                rejected.append({"term": term, "classification": "DUPLICATE", "reason": "equivalent query-intent variant"})
            continue
        level = int(item.get("source_level", 4))
        source_counts[key] += 1
        dedup[key] = {
            "term": term.strip(), "normalized": key, "classification": kind,
            "source_level": level, "source": item.get("source", "unknown"),
            "authorization": item.get("authorization"),
            "market_frequency": int(item.get("market_frequency", 0)),
        }

    pool = list(dedup.values())
    for item in pool:
        item["priority"] = priority(item["term"], item["classification"], item["source_level"], max(item.get("market_frequency", 0), source_counts[item["normalized"]]))
    pool.sort(key=lambda item: (-item["priority"], item["term"]))
    return {"product_facts": facts, "keyword_pool": pool, "rejected_keywords": rejected}


def build_query_universe(pool: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    def query_record(query: str, weight: float, source_level: int) -> dict[str, Any]:
        words = canonical(query).split()
        tail = "short_tail" if len(words) <= 1 else "mid_tail" if len(words) == 2 else "long_tail"
        return {
            "query": query,
            "weight": weight,
            "source_level": source_level,
            "evidence_level": source_level,
            "tail": tail,
            "cluster": semantic_cluster(query),
        }

    universe: dict[str, dict[str, Any]] = {}
    valid = list(pool)
    for item in valid:
        term = item["term"].strip()
        universe[semantic_cluster(term)] = query_record(term, item["priority"], item["source_level"])
    primary = [item for item in valid if item["classification"] == "PRIMARY"]
    for main in primary:
        for other in valid:
            if other is main or other["classification"] not in {"ATTRIBUTE", "SPECIFICATION", "COMPATIBILITY", "SECONDARY", "SYNONYM"}:
                continue
            phrase = f"{main['term']} {other['term']}"
            key = semantic_cluster(phrase)
            universe.setdefault(
                key,
                query_record(
                    phrase,
                    round((main["priority"] + other["priority"]) / 2, 4),
                    max(main["source_level"], other["source_level"]),
                ),
            )
    return sorted(universe.values(), key=lambda item: (-item["weight"], item["query"]))
